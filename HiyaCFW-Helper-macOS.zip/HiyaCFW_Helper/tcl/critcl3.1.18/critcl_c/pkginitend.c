  return TCL_OK;
#undef ip
}
#ifdef __cplusplus
}
#endif
